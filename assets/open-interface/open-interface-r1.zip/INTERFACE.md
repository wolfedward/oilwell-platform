# OWP-EDGE/1.0 井场设备开放接入标准

版本：1.0；日期：2026-09-23；状态：基础标量遥测对接版。本文是本项目的接口约定，不是国家、行业或认证标准。只有下表“已实现”能力可连接当前中心服务。示例是协议测试向量，不是现场记录。

## 1. 能力与适用边界

| 能力 | 当前状态 | 对接方式 |
| --- | --- | --- |
| Modbus TCP/RTU 读取标量 | 已实现 | 平台网关读取 FC03/FC04，点表可配置 |
| MQTT 5 标量上报 | 已实现 | 终端直接上报，或经平台网关转发 |
| PostgreSQL 幂等入库、历史查询 | 已实现 | 原始报文、测量/接收时间和来源留存 |
| 设备注册、井号绑定、点表审批/下发 | 后续实现 | 当前人工配置账号、ACL、网关本地点表；不得自动认领井号 |
| 同步三相波形、同周期双功图 | 设计草案 | 见 ROADMAP.md；不能向 v1 塞入数组或新字段 |
| 应用层逐报文入库回执 | 后续实现 | MQTT PUBACK 不能冒充中心业务入库回执 |
| 固件升级、远程启停、自动保护 | 未开放 | 当前接口不得写寄存器，不接执行线圈 |

本地软件虚拟终端使用的旧二进制接口不是本标准的厂家入口。不得把仿真身份自动登记为真实设备。`source` 为来源声明而非可信证明；准入需结合受控身份和现场核验。

## 2. 两种设备接入方式

1. **标准 Modbus 终端 + 平台网关（首选）**：厂家提供寄存器说明、读写属性、量程、单位、字节/字顺序及校准报告；网关负责轮询、换算、缓存和 MQTT。
2. **自主 MQTT 终端**：厂家实现本报文、TLS、唯一身份、持久缓存与重发；必须通过相同协议测试。设备不依赖特定 DSP/MCU 品牌。

两者共用中心数据模型。禁止“读到任何设备就自动上线”；目前身份通过运维配置，注册中心完成后转为受控登记。

## 3. MQTT 传输与身份

- 协议 MQTT 5.0；遥测 QoS=1；Retain=false。公网/跨主机连接必须使用 TLS 与服务端证书验证；部署建议端口 8883，端口不是身份凭据。
- 每网关独立 `client_id`、凭据/客户端证书；禁止共用万能密码。凭据不放在示例、点表、网页或 Git 中。
- 命名空间：`{prefix}/v1/{gateway_id}/{device_id}/telemetry`，默认 prefix=`oilfield`。prefix 最多 64 字符；其余标识最多 128 字符，允许 ASCII 字母、数字、下划线、点、冒号、连字符且首字符须字母或数字。
- 上报身份须与主题一致。中心并不能仅凭报文证明设备身份；Broker ACL 必须限制账号可发布的网关和终端路径。一个设备的账号不得发布其它井设备的数据。
- 当前参考 ACL 允许某网关下任意终端；生产部署应按登记台账枚举到具体终端，或保证该网关只连接受控终端。跨网关冒用必须被拒绝。
- 中心消费者保持稳定 client_id、Clean Start=false、默认会话保留 7 天。Broker 必须持久化并配置磁盘容量、保留期和告警；会话过期或 Broker 丢失持久状态仍会导致待确认数据丢失。
- 网关与 Broker 的 PUBACK 只代表该 MQTT 跳的交付。当前网关收到 PUBACK 后标记本地队列已发送；它不证明中心数据库已提交。中心对消费消息在数据库提交后才 PUBACK。端到端应用回执是后续版本，不能宣称全链路 exactly-once。

依据：[OASIS MQTT 5.0](https://docs.oasis-open.org/mqtt/mqtt/v5.0/mqtt-v5.0.html)。本项目 JSON 不是 Sparkplug；未实现 Sparkplug birth/death、metric alias 或 protobuf，不能标记 Sparkplug 兼容。

## 4. 报文字段与一致性

UTF-8 JSON，总长度不超过 1,048,576 字节，每报文 1—5000 个标量样本。不允许重复 JSON 键、NaN、Infinity、未知字段。结构见 `telemetry.schema.json`，完整例子见 `telemetry-example.json`。

| 字段 | 类型 | 规则 |
| --- | --- | --- |
| schema | 字符串 | 固定 `oilwell.telemetry.v1` |
| message_id | 标识符 | 全平台唯一，推荐 UUID；重发必须原样复用 |
| gateway_id / device_id | 标识符 | 与主题逐字一致；大小写敏感 |
| boot_id | 标识符 | 每次网关启动新建，重发历史消息保留旧 boot_id |
| created_at | UTC 时间 | 报文创建时间，RFC3339 秒/最多 6 位小数，Z 或 +00:00 |
| sequence | 对象 | first/last 与首尾样本序号相等 |
| samples | 数组 | 1—5000 行，序号非递减；同采集周期多测点可同序号 |

每行必须包含 `point, measured_at, sequence, value, quality, unit, source`，不得少字段。value 是换算后的有限工程值，不是原始寄存器；unit 是 1—32 个 Unicode 码点的单位字符串或 null，不允许 NUL (U+0000) 或孤立代理码点 (U+D800—U+DFFF)，以避免 PostgreSQL jsonb 无法入库；合法的代理对应解码成对应的 Unicode 码点。单位为空不代表无量纲，须在点表解释。quality 只允许 good/uncertain/bad。source 常用 modbus-tcp、modbus-rtu、device-adc；仿真应保留虚拟来源标识。约束依据：[PostgreSQL JSON 类型](https://www.postgresql.org/docs/current/datatype-json.html)。

sequence 范围 0—9223372036854775807，不接受布尔值；上报为 JSON 整数。JavaScript 厂家实现不得经 Number 损坏大整数；查询接口将序号返回十进制字符串。单个采集周期加 1；不同 boot_id 不连算丢包。

measured_at 必须表达实际采样/快照时刻。现有通用 Modbus 网关采用轮询开始时间，不代表 ADC 硬件时间戳，也不能证明多次读取同相位同步。需要同步功图时必须使用后续周期波形协议。缺测不得补造 good=0；保留本地通信错误，等待后续质量事件协议补齐故障上行。

重发必须使用**相同字节**。当前中心按 message_id 和原始字节 SHA-256 检查幂等；重新排键或改时间可能触发冲突。SHA-256 只用于完整性/冲突识别，不是设备数字签名。冲突或畸形消息当前会拒绝且不确认，尚无持久隔离队列，需运维处理，不能无条件无限灌入生产主题。

工程值按 IEEE754 binary64 使用，允许正常舍入但禁止溢出为无穷或非零数下溢成零。报文原始数字还须能保存为 PostgreSQL jsonb 数值：十进制小数位最多 16383 位、整数位最多 131072 位，禁止使用极端指数拼写零来绕过范围检查；建议只发送传感器有效精度内的简洁数值。序号另按 64 位整数检查，不经过浮点转换。JSON Schema 不能检查解析前的数字拼写，必须同时运行离线校验器。依据：[PostgreSQL 数值类型](https://www.postgresql.org/docs/current/datatype-numeric.html)。

## 5. Modbus 基础映射

- 当前支持 TCP 和 RTU；只读功能码 03/04，每批最多 125 个 16 位寄存器。
- 地址用 **0 起算 PDU 地址**；不要把说明书的 30001/40001 直接当 address。Unit ID 为 1—247。
- 支持 uint16/int16/uint32/int32/float32/float64；byte_order 与 word_order 必须显式约定。float32 big/big 表示 IEEE754 的高字先、高字节先，例如 5.8 的编码须按实际工具打包，不能人工四舍五入寄存器字。
- 工程值 = 原始值 × scale + offset。超出配置工程范围为 uncertain；无响应不生成假的成功样本。
- 参考新终端采用 RTU 19200、8E1，现场可配置。当前软件 RTU 默认是 8N1，厂家接入必须显式填写 parity/stopbits，不能依赖默认值。
- Modbus 本身不提供当前使用路径的加密认证；仅在受控 OT 网段/隔离串口使用，不将 502 端口暴露到互联网。

下面是**供新设备选择的参考点表**，不是所有厂家必须修改固件采用的固定地址；实际地址通过配置适配。全部为 FC04、float32、big/big、scale=1、offset=0，单值占两个寄存器。是否具备某测点须按设备能力登记。

| PDU 地址 | point | unit | 含义 |
| ---: | --- | --- | --- |
| 0 | motor.active_power | kW | 三相总有功功率，发电回馈时允许负值 |
| 2 | motor.current | A | 三相 RMS 电流算术平均，明确不是单相瞬时电流 |
| 4 / 6 / 8 | motor.voltage_a / _b / _c | V | 各相对中性点 RMS；无中性点设备另用 line_voltage_ab 等点名 |
| 10 / 12 / 14 | motor.current_a / _b / _c | A | 各相 RMS 电流 |
| 16 | motor.frequency | Hz | 电气基频，不是抽油冲次 |
| 18 | motor.speed | rpm | 测得机械转速；估算值须另命名 speed_estimated |
| 20 | rod.load | kN | 光杆载荷，含测点标定方向 |
| 22 | rod.displacement | m | 光杆位移，以校准零位为基准 |
| 24 | pump.stroke_rate | min^-1 | 每分钟完整往复次数 |
| 26 | cabinet.temperature | degC | 指定位置柜内温度 |

依据：[Modbus 官方规范入口](https://www.modbus.org/modbus-specifications)。终端快照一致性、跨块冻结和设备时间寄存器仍需在下一版驱动中实现；仅分配地址不构成同步采样能力。

## 6. 厂家自测与入场验收

下载本目录文件，在无平台依赖的 Python 3.10+ 环境运行：

```text
python validate_telemetry.py --topic oilfield/v1/GW-EXAMPLE/D-EXAMPLE/telemetry --file telemetry-example.json
```

成功退出码 0，失败退出码 2；工具不联网、不读取平台凭据、不下发指令。JSON Schema 验证结构，工具补充主题一致性、字节上限、重复键和序号关系检查。厂家 profile 比旧中心解析器更严格；工具通过不等于硬件合格，也不等于中心所有输入边界已完成加固。

| 编号 | 验收项 | 必须观察到的结果 |
| --- | --- | --- |
| P01 | 身份/主题错误 | 无权账号被 Broker 拒绝；报文/主题不符不进入遥测表 |
| P02 | 断网后恢复 | 同 message_id、同字节补发，可查原始测量时间 |
| P03 | 重复消息 | 不重复累计入库；冲突 ID 明确拒绝 |
| P04 | 非法类型/超限/异常值 | 自检拒绝；中心缺少的检查必须关闭后才准入 |
| P05 | 字节序/缩放 | 标准源输入和结果一致，覆盖正负、零点、上下量程 |
| P06 | 时钟漂移/重启 | 标识异常；boot_id 更新，不虚构在线或连续序号 |
| P07 | Broker/数据库异常 | 保留未确认消息，恢复后查询核对；测试持久化重启场景 |
| P08 | 满磁盘/缓存满 | 明确告警、确定背压/丢弃策略，不静默丢数 |
| P09 | 成对功图 | 同周期、同时间基准与标定信息，不能以 v1 标量代替 |
| P10 | 电气/安全 | 厂家提供绝缘、EMC、环境、危险区适用性和保护验证材料 |

厂家交付设备说明、版本、点表、校准记录、协议测试报告、升级/回退方案及故障响应负责人。平台方另行批准生产准入；协议自测不自动颁发生态认证。

## 7. 开放范围

本接入包可离线复制；平台通过 `/assets/open-interface/index.html` 提供无账号的文档/示例下载，不公开配置、口令、测点数据或管理 API。当前 HTTP 服务仍只监听本机；本页存在不等于互联网已发布。部署对外文档门户需另配 HTTPS 与访问策略。

本目录原创材料的许可见 LICENSE.txt。第三方芯片原理图、商标、固件与标准文本没有复制进包，不属于本项目许可范围。
